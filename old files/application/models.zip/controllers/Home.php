<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
class Home extends CI_Controller {
    public function __construct() { 
        parent::__construct();
        
        // Load the admin model
        $this->load->model('Admin_model'); 
    }

  /*Function to set JSON output*/
  public function output($Return=array()){
    /*Set response header*/
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: GET, OPTIONS");
    header("Content-Type: application/json; charset=UTF-8");
    /*Final JSON response*/
    exit(json_encode($Return));
  }
   public function home()
  {   
    $this->session->set_userdata('lastpage', $this->router->fetch_method());
       $this->load->view('home/index');
  }
  public function index()
  {   
    $this->session->set_userdata('lastpage', $this->router->fetch_method());
       $this->load->view('home/index');
  }
  public function signup()
  {   
    $this->session->set_userdata('lastpage', $this->router->fetch_method());
       $this->load->view('home/signin');
  }
  public function login()
  {   
     
       $this->load->view('home/login');
  }
  public function wishlist()
  {  
  $this->session->set_userdata('lastpage', $this->router->fetch_method());
   $homesession = $this->session->userdata('customerdet');
    if(empty($homesession)){ 
     echo false ;
     exit ;
    }

    $data['wishlist'] = $this->Admin_model->get_all_data('wishlist',array('user_id'=>$homesession['user_id']));
    $this->load->view('home/wishlist',$data);
  }
  public function about()
  {   
    $this->session->set_userdata('lastpage', $this->router->fetch_method());
       $this->load->view('home/home');
  }
   public function profile()
  {   
    $this->session->set_userdata('lastpage', $this->router->fetch_method());
       $this->load->view('home/profile');
  }
  public function industry()
  {   
    $this->session->set_userdata('lastpage', $this->router->fetch_method());
      $data['categories'] = $this->Admin_model->get_all_data('categories',''); 
      $data['products'] = $this->Admin_model->get_all_data('industry_products',''); 
      $this->load->view('home/shop',$data);
  }
  public function school()
  {   
    $this->session->set_userdata('lastpage', $this->router->fetch_method());
      $data['schools'] = $this->Admin_model->get_all_data('school_master',array('status' => 'Y'));
      $this->load->view('home/school-shop',$data);
  }
  public function getschooldet()
  {  

     $school = $this->input->post('schoolid') ;
     $schools = $this->Admin_model->get_single_data('school_master',array('id'=>$school));
     $levels = $schools->class_levels ;
     $type = $schools->school_type ;

     $data['schoolid'] =  $school  ;
     $data['logo'] =  $schools->school_logo  ;
     $data['type'] =   $type ;
     //$levels = explode(',',$levels);

    $this->db->select('class_level');
     $this->db->where('school_id', $school);
     $this->db->where('status', 1);
     
     $level = $this->db->get('uniform_school_relation')->result_array();

    
     $lev = array();  
foreach($level as $l){
$cls = explode(',',$l['class_level']);
foreach($cls as $cl){
  $lev[] = $cl ;
} 
}
if(!empty($lev)){
  $this->db->select('id,standard_name');
  $this->db->where_in('id',  $lev);
  $data['classes'] = $this->db->get('standard_master')->result_array();
  
  $this->load->view('home/uniform_select',$data);
}else{
  echo false ;
}

    
  }

  function uniform_tosession(){
     $formdata =  $this->input->post('uniformdata');
    if(!empty($formdata)){
     parse_str($this->input->post('uniformdata'), $data_array);
     $uniformdata = array(
     'schoolid' => $data_array['schoolid'],
     'gender' =>  $data_array['gender'],
     'class' =>  $data_array['selected_class'],      
     );
     // Add uniform data in session
     $this->session->set_userdata('uniformdata', $uniformdata);
     if($uniformdata){
          echo 1 ;
     }else{
        echo 0 ;
     }
    }else{
     redirect('home/school', 'refresh');  
    }
  }


  public function uniform_details()
  {   
     $id = $this->uri->segment(3) ;
     $data['uniformdata'] = $this->Admin_model->get_single_data('school_products',array('id'=>$id));
         
     $pimages  = array();
     $pimage = '' ;
     $product_images = $this->Admin_model->get_all_data('school_product_images',array('product_id'=>$id)); 
    foreach($product_images as $images){
     $pimage .= "," .$images['product_images'];
    }
    $pimages  = explode(',',$pimage) ; 
    $data['product_images'] = $pimages ;
      $data['product_price'] = $this->Admin_model->get_single_data('school_product_price_size_det',array('product_id'=>$id,'status'=>'Y'));  
   //  $data['inventory'] = $this->get_stock_det($id); 
     $this->load->view('home/school-product-details', $data);
  }


  public function confirm_uniform(){
    $uniformsession = $this->session->userdata('uniformdata');
    if(!empty($uniformsession)){
   // $class_level = $this->Admin_model->get_type_name_by_id('standard_master','id',$uniformsession['class'],'type_id');

    $get_uniforms = $this->Admin_model->get_all_data('uniform_school_relation',array('school_id'=>$uniformsession['schoolid'],'status'=>1 , 'find_in_set("'.$uniformsession['class'].'", class_level) <> 0'));
    if($uniformsession['gender'] == 'male'){
        $gender = 1 ;
    }else if($uniformsession['gender'] == 'female'){
        $gender = 2 ;
    }
    $data = array();
    if(!empty($get_uniforms)){

  
      foreach($get_uniforms as $uniform){

          $this->db->where('id',$uniform['uniform_id']);
          $this->db->group_start();
          $this->db->where("find_in_set( $gender, genders)");
          $this->db->group_end();
          $uniformdata = $this->db->get('school_products')->row();

          if(!empty($uniformdata)){
                $udata[] = $uniformdata ;
                $schoolid[] = $uniformsession['schoolid'] ;
                $gender_selected[] = $gender ;
                $pimages  = array();
                $pimage = '' ;
                $product_images = $this->Admin_model->get_all_data('school_product_images',array('product_id'=>$uniform['uniform_id'])); 
              foreach($product_images as $images){
                $pimage .= "," .$images['product_images'];
              }
              $pimages  = explode(',',$pimage) ; 
          $product_images[] = $pimages ;
          $product_price[] = $this->Admin_model->get_single_data('school_product_price_size_det',array('product_id'=>$uniform['uniform_id'],'status'=>'Y'));  
          }
          $data['uniformdata'] = $udata ;
          $data['schoolid'] = $schoolid ;
          $data['gender_selected'] = $gender_selected ;
          $data['product_images'] = $product_images ;
          $data['product_price'] = $product_price;  
      }
    }
     

 
    if(!empty( $data)){
        $this->load->view('home/confirm_uniform',$data);
    } else{
        redirect('home/school','refresh');
    }
    }else{
        redirect('home/school','refresh');
    }
  }


public function uniform(){
    $uniformsession = $this->session->userdata('uniformdata');
    if(!empty($uniformsession)){
   // $class_level = $this->Admin_model->get_type_name_by_id('standard_master','id',$uniformsession['class'],'type_id');

    $get_uniforms = $this->Admin_model->get_all_data('uniform_school_relation',array('school_id'=>$uniformsession['schoolid'],'status'=>1 , 'find_in_set("'.$uniformsession['class'].'", class_level) <> 0'));
    if($uniformsession['gender'] == 'male'){
        $gender = 1 ;
    }else if($uniformsession['gender'] == 'female'){
        $gender = 2 ;
    }
    $data = array();
 
    if(sizeof($get_uniforms)>1 ){


        $udata = array() ;
        $schoolid  = array() ;
        $gender_selected  = array() ;
        $product_images = array() ;
        $product_price= array() ;


        
      foreach($get_uniforms as $uniform){

        $this->db->where('id',$uniform['uniform_id']);
        $this->db->group_start();
        $this->db->where("find_in_set( $gender, genders)");
        $this->db->group_end();
        $uniformdata = $this->db->get('school_products')->row();
      

        if(!empty($uniformdata)){
              $udata[] = $uniformdata ;
              $schoolid[] = $uniformsession['schoolid'] ;
              $gender_selected[] = $gender ;
              $pimages  = array();
              $pimage = '' ;
              $product_images = $this->Admin_model->get_all_data('school_product_images',array('product_id'=>$uniform['uniform_id'])); 
            foreach($product_images as $images){
              $pimage .= "," .$images['product_images'];
            }
            $pimages  = explode(',',$pimage) ; 
        $product_images[] = $pimages ;
        $product_price[] = $this->Admin_model->get_single_data('school_product_price_size_det',array('product_id'=>$uniform['uniform_id'],'status'=>'Y'));  
        }
        
    }
        $data['uniformdata'] = $udata ;
        $data['schoolid'] = $schoolid ;
        $data['gender_selected'] = $gender_selected ;
        $data['product_images'] = $product_images ;
        $data['product_price'] = $product_price; 

       

      if(!empty( $data)){

       // echo 'from view' ;
      $this->load->view('home/confirm_uniform',$data);
      } else{
          redirect('home/school','refresh');
      }


    }else if(sizeof($get_uniforms) == 1 ){

      foreach($get_uniforms as $uniform){

        $this->db->where('id',$uniform['uniform_id']);
        $this->db->group_start();
        $this->db->where("find_in_set( $gender, genders)");
        $this->db->group_end();
        $uniformdata = $this->db->get('school_products')->row();

        if(!empty($uniformdata)){
              $data['uniformdata'] = $uniformdata ;
              $data['schoolid'] = $uniformsession['schoolid'] ;
              $data['gender_selected'] = $gender ;
              $pimages  = array();
              $pimage = '' ;
              $product_images = $this->Admin_model->get_all_data('school_product_images',array('product_id'=>$uniform['uniform_id'])); 
            foreach($product_images as $images){
              $pimage .= "," .$images['product_images'];
            }
            $pimages  = explode(',',$pimage) ; 
        $data['product_images'] = $pimages ;
        $data['product_price'] = $this->Admin_model->get_single_data('school_product_price_size_det',array('product_id'=>$uniform['uniform_id'],'status'=>'Y'));  
        }
    }

  if(!empty( $data)){
      $this->load->view('home/school-product-details',$data);
  } else{
      redirect('home/school','refresh');
  }

    }else{
      redirect('home/school','refresh');
  }
    
    }else{
        redirect('home/school','refresh');
    }
  }

  public function contact()
  {   
       $this->load->view('home/contact');
  }

 
  public function send_enquiry() {
    
    $firstname = $this->input->post('name');
    $email = $this->input->post('email');
    $subject = $this->input->post('subject');
    $phone = $this->input->post('phone');
    $message = $this->input->post('message');
    $message = $this->input->post('message');
    date_default_timezone_set('Asia/Riyadh');
    $today      = date("Y-m-d H:i:s");

     $Return = array('result'=>'', 'error'=>'');

    /* Server side PHP input validation */    
    if($this->input->post('name')==='') {
          $Return['error'] = "Please enter your name ";
    }else if($this->input->post('email')==='') {
          $Return['error'] = "Please enter a valid Email ID";
    } else if (filter_var($this->input->post('email'), FILTER_VALIDATE_EMAIL) === false)  {
     $Return['error'] = $this->Admin_model->translate("Invalid Email ID entered");
    } else if($this->input->post('phone')==='') {
          $Return['error'] = "Please enter Phone No.";
    }else if($this->input->post('subject')==='') {
          $Return['error'] = "Please add your subject of enquiry";
    }else if($this->input->post('message')==='') {
          $Return['error'] = "Please add your message ";
    }  


      if($Return['error']!=''){
        $output['status'] = 'ERROR';
        $output['message'] = $Return['error'];
        echo json_encode($output);
        exit ;
      }


    $fname = '' ;

     if(is_uploaded_file($_FILES['attachment']['tmp_name'])) {
      //checking image type
      $allowed =  array('png','jpg','jpeg','pdf','gif','PNG','JPG','JPEG','PDF','GIF');
      $filename = $_FILES['attachment']['name'];
      $ext = pathinfo($filename, PATHINFO_EXTENSION);
      if(in_array($ext,$allowed)){
        $tmp_name = $_FILES["attachment"]["tmp_name"];
        $profile = "uploads/images/enquiry/";
        
        $name = basename($_FILES["attachment"]["name"]);
       // $newfilename = 'cat_'.round(microtime(true)).'.'.$ext;

        $newfilename = round(microtime(true)).'_'.$name ;
        move_uploaded_file($tmp_name, $profile.$newfilename);
        $fname = $newfilename;
         
 
  }else {
         
        $output['status'] = 'ERROR';
        $output['message'] = 'Invalid file format';
         echo json_encode($output);
         exit ;

      }
     
  }


    
    $data = array(
      'name' => $firstname ,
      'email' => $email,
      'phone' => $phone,
      'subject' => $subject,
      'message' => $message,
      'attachment' =>$fname,
      'created_on' => $today ,
      'status' => 1
    );

   $insert =  $this->db->insert('enquiry_messages',$data);
     
       
                
      
      if($insert){
         $output['status'] = 'SUCCESS';
         $output['message'] = 'Your enquiry has been sent.';
          
      } else {
        $output['status'] = 'ERROR';
        $output['message'] = 'Failed to send enquiry';
      }
      
    
    echo json_encode($output);
  }

 

  public function product_details()
  {   
     $id = $this->uri->segment(3) ;
     $data['product'] = $this->Admin_model->get_single_data('industry_products',array('id'=>$id));
         
     $pimages  = array();
     $pimage = '' ;
     $product_images = $this->Admin_model->get_all_data('industry_product_images',array('product_id'=>$id)); 
    foreach($product_images as $images){
     $pimage .= "," .$images['product_images'];
    }
    $pimages  = explode(',',$pimage) ; 
    $data['product_images'] = $pimages ;
      $data['product_price'] = $this->Admin_model->get_single_data('industry_product_price_size_det',array('product_id'=>$id,'status'=>'Y'));  
   //  $data['inventory'] = $this->get_stock_det($id); 
     $this->load->view('home/product-details', $data);
  }
  public function get_stock_det($product_id){
   $inventory_data =  $this->Admin_model->get_all_data('industry_inventory', array('product_id',$product_id));
    //    foreach($inventory_data as $data){
    //    }
  }

  function addtocart()
  {
    
   $pagetype =  $this->input->post('pagetype');
   $type =  $this->input->post('type');
  if($pagetype == "detail"){
    parse_str($this->input->post('formdata'), $data_array);
   }else if($pagetype == "home" && $type == "industry")
   {
    $data_array['product_id']= $this->input->post('formdata');
    $product = $this->Admin_model->get_single_data('industry_products',array('id'=>$data_array['product_id']));
    $data_array['color_selected'] = explode(',', $product->colors_available)[0];
    $data_array['size_selected'] = explode(',', $product->sizes_available)[0];
    $data_array['gender_selected'] = explode(',', $product->genders)[0];
    $product_price= $this->Admin_model->get_single_data('industry_product_price_size_det',array('product_id'=>$data_array['product_id'],'status'=>'Y','size_id'=>$data_array['size_selected']));  
    $data_array['product_price'] =  $product_price->product_price;
   } //echo  $data_array->product_id;
   if( $type == 'industry'){
  // Set array for send data.
    $data = array(
      'id' => (int) $data_array['product_id'],
      'name' => htmlspecialchars($this->Admin_model->get_type_name_by_id('industry_products','id',$data_array['product_id'],'product_name') ),
      'price' => $data_array['product_price'],
      'qty' => 1,
        'color' =>$data_array['color_selected'],
      'size' =>$data_array['size_selected'],
      'gender'=>$data_array['gender_selected'],      
      'type' => 'industry'
      );   
   }else{
    $this->session->unset_userdata('uniformdata');
       // Set array for send data.
      $data = array(
        'id' => (int) $data_array['product_id'],
        'name' => htmlspecialchars($this->Admin_model->get_type_name_by_id('school_products','id',$data_array['product_id'],'product_name') ),
        'price' => $data_array['product_price'],
        'qty' => 1,
          'color' =>$data_array['color_selected'],
        'size' =>$data_array['size_selected'],
        'gender'=>$data_array['gender_selected'],          
        'type' => 'school'
        );   
    }
    $result = $this->cart->insert($data);
    if($result) {
      $Return['result'] = true;
      $rows = count($this->cart->contents());
      $Return['items'] = $rows;
    } else {
      $Return['result'] = false;
    }
    $this->output($Return);
    exit;
   
  }
  function quick_view(){
   $productid = $this->input->post('productid');
   $from = $this->input->post('from');

   if($from == 'industry'){
     $data['product'] = $this->Admin_model->get_single_data('industry_products',array('id'=>$productid));
     $data['product_price'] = $this->Admin_model->get_single_data('industry_product_price_size_det',array('product_id'=>$productid,'status'=>'Y'));  
 
    }else{
        $data['product_price'] = $this->Admin_model->get_single_data('school_product_price_size_det',array('product_id'=>$productid,'status'=>'Y'));  
        $data['product'] = $this->Admin_model->get_single_data('school_products',array('id'=>$productid));
      }
      $data['folder'] = $from  ;
      $this->load->view('home/quick_view',$data) ;
  }

   function add_to_wishlist(){
    
    $homesession = $this->session->userdata('customerdet');
    if(empty($homesession)){ 
     echo false ;
     exit ;
    }


   $productid = $this->input->post('productid');
   $from = $this->input->post('from');

   if($from == 'industry'){
     $data['product'] = $this->Admin_model->get_single_data('industry_products',array('id'=>$productid));
     $data['product_price'] = $this->Admin_model->get_single_data('industry_product_price_size_det',array('product_id'=>$productid,'status'=>'Y'));  



 
    }else{
        $data['product_price'] = $this->Admin_model->get_single_data('school_product_price_size_det',array('product_id'=>$productid,'status'=>'Y'));  
        $data['product'] = $this->Admin_model->get_single_data('school_products',array('id'=>$productid));
      }
      $data['folder'] = $from  ;

$wishlist = array('user_id'=> $homesession['user_id'],
'type' => $from,
'product_id'=> $productid,
'created_on'=> date('Y-m-d H:i')
);
     $this->Admin_model->insert_data('wishlist',$wishlist) ;


      $this->load->view('home/added_to_wishlist',$data) ;
  }


  
  function added_tocart(){
     $productid = $this->input->post('productid');
     $from = $this->input->post('from');
  
     if($from == 'industry'){
       $data['product'] = $this->Admin_model->get_single_data('industry_products',array('id'=>$productid));
     }else{
       $data['product'] = $this->Admin_model->get_single_data('school_products',array('id'=>$productid));
     }
     $data['folder'] = $from  ;
     $this->load->view('home/added_to_cart',$data) ;
    }

 
  function viewcart()
  {

    $homesession = $this->session->userdata('customerdet');
    if(empty($homesession)){ 
     redirect('home');
    }

  $this->load->view('home/cart');
  }

  function loadcartqty()
  {
  $rows = count($this->cart->contents());
  echo  $rows ;
  }
  function remove($rowid) {
      $viewname =  $_POST['viewname'] ;
  // Check rowid value.
      if ($rowid==="all"){
      // Destroy data which store in  session.
      $this->cart->destroy();
      }else{
      // Destroy selected rowid in session.
      $data = array(
      'rowid'   => $rowid,
      'qty'     => 0
      );
      // Update cart data, after cancle.
      $this->cart->update($data);
      }
      if($viewname=="checkout"){
          //echo $viewname ;
        $this->load->view('home/loadcheckout');
      }else if($viewname=="viewcart"){
          $this->load->view('home/loadcart');
          //echo $viewname ;
      }
      else if($viewname=="cart"){
          $this->viewcart();
          //echo $viewname ;
      }
      // This will show cancle data in cart.
      //redirect('user/home/viewcart');
  }

  function update_cart(){
      $viewname =  $this->input->post('viewname') ;
      //$this->load->library("cart");
      // Recieve post values,calcute them and update
      $rowid = $this->input->post('rowid');
      $price = $this->input->post('price');
      $qty = $this->input->post('qty');

      $data = array(
          'rowid' => $rowid,
          'price' => $price ,          
          'qty' => $qty
          );
     // print_r($data);
   $this->cart->update($data);
      if($viewname=="checkout"){
          //echo $viewname ;
        $this->load->view('home/loadcheckout');
      }else if($viewname=="viewcart"){
          $this->load->view('home/loadcart');
          //echo $viewname ;
      }
      }
  function checkout()
  { 

    $homesession = $this->session->userdata('customerdet');
    if(empty($homesession)){ 
     redirect('home/login');
    }
  
     $this->load->view('home/checkout');
     
  }

  public function place_order()
  {   
     $Return = array('result'=>'', 'error'=>'');  
     if($Return['error']!=''){
        $this->output($Return);
    }

    $include_logo = false ;
    $fname = '' ;

        $data = array(   
          'first_name' => $this->input->post('ltn__name'),
          'last_name'=>$this->input->post('ltn__lastname'),
          'email_address'=>$this->input->post('ltn__email'),
          'phone_no'=>$this->input->post('ltn__phone'),
          'company_name'=>$this->input->post('ltn__company'),
          'company_address'=>$this->input->post('ltn__company_address'),
          'address_line1'=>$this->input->post('address_line1'),
          'address_line2'=>$this->input->post('address_line2'),
          'city'=>$this->input->post('city'),
          'state'=>$this->input->post('state'),
          'zip_code'=>$this->input->post('zip_code'),
          'country'=>$this->input->post('country'),
          'created_on'=>date('Y-m-d H:i:s'),
            );

          if($this->input->post('include_logo')){

            $include_logo = true ;

            if(is_uploaded_file($_FILES['identity_card']['tmp_name'])) {
              //checking image type
              $allowed =  array('png','jpg','jpeg','pdf','gif','PNG','JPG','JPEG','PDF','GIF');
              $filename = $_FILES['identity_card']['name'];
              $ext = pathinfo($filename, PATHINFO_EXTENSION);
              if(in_array($ext,$allowed)){
                $tmp_name = $_FILES["identity_card"]["tmp_name"];
                $profile = "uploads/images/industry/";
                $set_img = base_url()."uploads/images/industry/";
                // basename() may prevent filesystem traversal attacks;
                // further validation/sanitation of the filename may be appropriate
                $name = basename($_FILES["identity_card"]["name"]);
               // $newfilename = 'cat_'.round(microtime(true)).'.'.$ext;
        
                $newfilename = round(microtime(true)).'_'.$name ;
                move_uploaded_file($tmp_name, $profile.$newfilename);
                $fname = $newfilename;
                 
         
          }else {
                $Return['error'] = $this->Admin_model->translate("Invalid file format");
              }
            if($Return['error']!=''){
              $this->output($Return);
            }
          }

          }
          $result = $this->Admin_model->insert_data('customer_master', $data);
          $customeid =  $this->db->insert_id();
          $cart = $this->cart->contents() ;
          foreach($cart as $cartdata){
               $order_data = array(
                    'customer_id' =>$customeid  ,
                    'order_details' => json_encode($cartdata),
                    'address_details' => json_encode($data),
                    'total_amount' => $cartdata['subtotal'],
                    'type' => $cartdata['type'],
                    'include_logo' => $include_logo,
                    'identity_card' => $fname ,
                    'vat_amount' => 0,
                    'shipping_charge' => 0,
                    'created_on' => date('Y-m-d H:i:s'), 
                    'status' => 1,
                    'notes' => $this->input->post('ltn__message')
                 ) ;
            $result = $this->Admin_model->insert_data('order_master', $order_data);
          }
    if ($result == TRUE) {     
      //get setting info 
       $Return['result'] = 'Order Placed Successfully.';
    } else {
      $Return['error'] =  'Bug. Something went wrong, please try again';
    }
    $this->output($Return);
    exit;
  }

    public function submitsignup()
  {   
    $Return = array('result'=>'', 'error'=>'');
      if($this->input->post('name')==='') {
            $Return['error'] = "Name Required";
      }else if($this->input->post('email')==='') {
        $Return['error'] = "Email address Required";
      }else if($this->input->post('phone')==='') {
        $Return['error'] = "Phone number Required";
      }       
      if($Return['error']!=''){
            $this->output($Return);
            exit ;
        }
      $data = array(   
      'name' => $this->input->post('name'),
      'email' => $this->input->post('email'),
      'phone' => $this->input->post('phone'),
        );
      $result = $this->db->insert('customers',$data);
      $inserid =  $this->db->insert_id();

      if ($result == TRUE) {
        $Return['result'] = 'Signed up successfully.';
      } else {
        $Return['error'] =  'Bug. Something went wrong, please try again';
      }
      $this->output($Return);
      exit;
  }
  public function otp()
  {   
       $this->load->view('home/otp');
  }
  
  public function sentotp()
  {   
    $Return = array('result'=>'', 'error'=>'');
    if($this->input->post('phone')==='') {
      $Return['error'] = "Phone number Required";
    } 
    
    $this->db->where('phone',$this->input->post('phone'));
    $query = $this->db->get('customers');
    if ($query->num_rows() == 0){
      $Return['error'] = "Phone number does not exists";
    }

    if($Return['error']!=''){
          $this->output($Return);
          exit ;
      }

      $otp = 1111;
      // $otp = str_pad(rand(0, pow(10, 4)-1), 4, '0', STR_PAD_LEFT);
      $data = array(   
      'otp' => $otp,
        );

        $this->db->where('phone',$this->input->post('phone'));
        $queryres = $this->db->get('customers')->row();

      $this->db->where('id',$queryres->id);
      $result = $this->db->update('customers',$data);
      $inserid =  $this->db->insert_id();

    if ($result == TRUE) {
      $Return['result'] = $queryres->phone;
    } else {
      $Return['error'] =  'Bug. Something went wrong, please try again';
    }
    $this->output($Return);
    exit;
  }

  public function verifyotp()
  {
    $Return = array('result'=>'', 'error'=>'');
    $phone =$this->input->post('phone');
    $resotp = $this->input->post('otp');
    $this->db->where('phone',$phone);
    $this->db->where('otp',$resotp);
    $this->db->where('status',1);
    $query = $this->db->get('customers');
    if ($query->num_rows() == 0){
      $Return['error'] = "Invalid otp";
    }
    if($Return['error']!=''){
      $this->output($Return);
      exit ;
    }else{
      $this->db->where('phone',$phone);
      $this->db->update('customers',array('verified'=>1));

      $userdata = $this->Admin_model->get_single_data('customers',array('phone'=>$phone,'otp'=>$resotp,'verified'=>1));
     
    if (!empty($userdata)) {
      
        $session_data = array(
        'user_id' => $userdata->id,
        'username' => $userdata->name,
        'useremail' => $userdata->email,
        'userphone' => $userdata->phone,
         
        );

        // Add user data in session
        $this->session->set_userdata('customerdet', $session_data);
        $lan = $this->session->userdata('language');
        if(empty($lan)){
        $this->session->set_userdata('language', 'English');
        $this->session->set_userdata('dir', 'ltr');
        }
         
        $Return['result'] = $this->Admin_model->translate('Logged In Successfully') ;        
        $this->output($Return);
    }
  }
}

public function redirect()
{
  $lastpage = $this->session->userdata('lastpage'); 
  redirect('home/'.$lastpage) ;
}

public function logout() {
  $session = $this->session->userdata('customerdet'); 
  $sess_array = array('customerdet' => '');
  $this->session->sess_destroy();
  $Return['result'] = 'Successfully Logout.';
  redirect(base_url().'home', 'refresh');
}
   
 
}