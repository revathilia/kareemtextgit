 <?php $this->load->view('industry/header');?>
<body>
<?php $this->load->view('industry/top_header');?>
<?php $this->load->view('industry/side_header');?>


<div id="wrapper">
<div class="main-content">
<div class="row small-spacing">
<div class="col-xs-12">
     <div class="box-content card white">
<div class="box-title row">
    <div class='col-md-4'><h4><?php echo $this->Admin_model->translate("Service List") ?></h4></div>
    <div class='col-md-4'></div>
    <div class='col-md-2'> 
         <a href="<?php echo base_url(); ?>industry/newservice"><button class="btn btn-warning btn-block"> <?php echo $this->Admin_model->translate("Add New") ?></button></a> 
 
    </div>
    <div class="col-md-2 ">
      <button type="button" class="btn btn-primary btn-sm btn-block changesort" data-toggle="modal"  data-target="#boostrapModal-1"   ><?php echo $this->Admin_model->translate("Change Service Order")?></button>
    </div>

</div>

 
<div class="box-content">
 <div class="table-responsive">
  <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
      <tr>
<th><?php echo $this->Admin_model->translate("No") ?></th>
<!-- <th>User Id</th> -->
<th><?php echo $this->Admin_model->translate("Service Name(English)") ?></th>
 <th><?php echo $this->Admin_model->translate("Service Name(Arabic)") ?></th>
<th><?php echo $this->Admin_model->translate("Service Description (English)") ?></th>
 <th><?php echo $this->Admin_model->translate("Service Description (Arabic)") ?></th>

 <th><?php echo $this->Admin_model->translate("status") ?></th>
  <th><?php echo $this->Admin_model->translate("Order") ?></th>

<th><?php echo $this->Admin_model->translate("Action") ?></th>
</tr>
      
</thead>
<tbody>
<?php foreach ($servicedet as $value) {
  ?>
 <tr>
<td><?php echo $value['id'] ?></td>
<!-- <th>User Id</th> -->
<td><?php echo  $this->Admin_model->translate($value['service_name']) ?></td>
<td><?php echo $this->Admin_model->translate($value['ar_service_name']) ?></td>
<td><?php echo  $this->Admin_model->translate($value['description']) ?></td>
<td><?php echo $this->Admin_model->translate($value['ar_description']) ?></td>

 <td>
  <?php if($value['status']=='Y'){ ?>

    <a onclick="statusupdate(<?php echo $value['id'] ?>,'D');  return false ;" href="javascript:void(0)"  class="btn btn-success btn-xs"><?php echo $this->Admin_model->translate('Enabled') ?> </a>

    

  <?php } else if($value['status']=='D'){ ?>
     
    <a onclick="statusupdate(<?php echo $value['id'] ?>,'Y');  return false ;" href="javascript:void(0)"  class="btn btn-danger btn-xs"><?php echo $this->Admin_model->translate('Disabled') ?> </a>

   
    
  <?php } ?>
  <br/> <br/>
  <?php if($value['login_required']=='yes'){ ?>

    <a onclick="loginupdate(<?php echo $value['id'] ?>,'no');  return false ;" href="javascript:void(0)"  class="btn btn-primary btn-xs"><?php echo $this->Admin_model->translate('Login Required') ?> </a>

    

  <?php } else if($value['login_required']=='no'){ ?>
     
    <a onclick="loginupdate(<?php echo $value['id'] ?>,'yes');  return false ;" href="javascript:void(0)"  class="btn btn-danger btn-xs"><?php echo $this->Admin_model->translate('Login Not Required') ?> </a>

   
    
  <?php } ?>
 

     </td>
<td><button type="button" class="btn btn-xs btn-default"  data-questionid = "<?php echo $value['id'] ?>"   ><?php echo $value['ordering']  ?></button></td>
   
<td>
 
<a href="<?php echo base_url()?>industry/editservice/<?php echo $value['id']?>">&nbsp;&nbsp;<button type="button" class="btn btn-info   btn-xs waves-effect waves-light"><i class="ico fa fa-pencil"></i></button></a><br/>


 <a onclick="statusupdate(<?php echo $value['id'] ?>,'delete');  return false ;" href="javascript:void(0)"  class="btn btn-danger    btn-xs waves-effect waves-light"> <i class="ico fa fa-trash"></i> </a>


    </td>

</tr>

  <?php
} ?>
  

</tbody>
    
    </table>
</div>


<!-- /.box-content -->
</div>
<!-- /.col-lg-6 col-xs-12 -->
</div>
</div>

</div>
</div>
</div>
</body>

<div class="modal fade" id="boostrapModal-1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content" id="serviceid">
      
    </div>
  </div>
</div>


 <?php $this->load->view('industry/footer');?>

 <script>
    function statusupdate($id,$status){

 
$.ajax({ 
type: "POST",
url: "<?php echo base_url(); ?>"+'admin/service_status/',
data: {id:$id,status:$status},
}).done(function(response){

 if(response=='false'){
   toastr.error("Access denied");
 }

location.reload();

});

}

  function loginupdate($id,$status){

 
$.ajax({ 
type: "POST",
url: "<?php echo base_url(); ?>"+'admin/login_status_service/',
data: {id:$id,status:$status},
}).done(function(response){

 if(response=='false'){
   toastr.error("Access denied");
 }

location.reload();

});

}


$(document).on('click', '.changesort', function(){  


// var serviceid = document.getElementById("service").value  ;
 
// var serviceid = $(this).data('serviceid') ;

 
$.ajax({  
url:"<?php echo base_url() ?>industry/changeservicessort",  
method:"POST",  
//data:{serviceid:serviceid,qid:questionid },
success:function(data){ 

$('#serviceid').html(data);  
$('#boostrapModal-1').modal('show');
    

}  
});  


});


</script>