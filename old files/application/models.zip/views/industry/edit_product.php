 <?php $this->load->view('industry/header');?>
<body>
<?php $this->load->view('industry/top_header');?>
<?php $this->load->view('industry/side_header');?>

<?php $session = $this->session->userdata('userdet');?>
 
 <div id="wrapper">
<div class="main-content">
<div class="row small-spacing">

  <div class="box-content card white">
<div class="box-title row">
    <div class='col-md-4'><h4><?php echo $this->Admin_model->translate("Edit Product") ?></h4></div>
    <div class='col-md-6'></div>
    <div class='col-md-2'> 
            <a href="<?php echo base_url(); ?>industry/products"><button class="btn btn-warning"><?php echo $this->Admin_model->translate("Product List") ?></button></a>
    </div>
</div>

 <div class="card-content">

      <?php $attributes = array('name' => 'edit_driver', 'id' => 'xin-form', 'autocomplete' => 'off');?>
        <?php $hidden = array('_user' => $session['i_user_id']);?>
        <?php echo form_open('industry/update_product', $attributes, $hidden);?>
        <div class="form-body">
          <div class="row"> 
            <input type="hidden" class = "userid" name="productid" value="<?php echo $product['id'] ?>">
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="first_name"><?php echo $this->Admin_model->translate("Product Name") ?></label>
                    <input class="form-control" placeholder="<?php echo $this->Admin_model->translate("Product name") ?>" name="product_name" type="text" value="<?php echo $product['product_name'] ?>">
                  </div>
                </div>
            </div>
 
			 
   <div class="row"> 
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="first_name"><?php echo $this->Admin_model->translate("Category") ?> </label>
                    
               
<?php echo $this->Admin_model->select_html('categories','id', 'category_name', 'category_name', 'edit', 'demo-chosen-select form-control required category_name',  $product['category']  , '', '', ''); ?>

   
                  </div>
                </div>
            </div>
           

            <div class="row"> 
                <div class="col-md-6">
                      <div class="form-group">
                      <label for="first_name"><?php echo $this->Admin_model->translate("Product Image") ?></label>
 
                      <input type="file" id="imgInp" name="product_image" onchange="readURL(this);" class="form-control " >
                      <small>Upload files only: gif,png,jpg,jpeg</small>

     
                  </div>
                </div>
                 <input type="hidden" name="iconname" id="iconname" value="<?php echo $product['product_image'];?>">

<div class="col-md-6">
        <div class='form-group'>
          <?php if($product['product_image']!='' && $product['product_image']!='no file') {?>
          <img   class="img-thumb" src="<?php echo base_url().'uploads/images/industry/'.$product['product_image'];?>" style="height:100px !important;width:100px !important;  " id="image">
          
           <a class="btn btn-xs btn-success" href="<?php echo site_url()?>download?type=images/industry&filename=<?php echo $product['product_image'];?>">Download</a><button class="btn btn-xs btn-warning" onclick="remove();return false;">Remove</button>
          
          <?php } else {?>
          <img   class="img-thumb" src="" style="height:100px !important;width:100px !important; " id="image">  
      
          <?php } ?> </div>
      </div>

              </div>
  
          
           
        </div>
        <div class="form-actions"> <?php echo form_button(array('name' => 'hrsale_form', 'type' => 'submit', 'class' => 'btn btn-primary', 'content' => '<i class="fa fa fa-check-square-o"></i>'.$this->Admin_model->translate("Save"))); ?> </div>
        <?php echo form_close(); ?> </div>

</div>
</div>
</div>
</div>
</body>


<!-- ================================================== -->
 <?php $this->load->view('industry/footer');?>




 <script type="text/javascript">
  imgInp.onchange = evt => {
  const [file] = imgInp.files
  if (file) {
    image.src = URL.createObjectURL(file)
  }
}

function readURL(input) {
    if (input.files && input.files[0]) {
var reader = new FileReader();

jQuery('#image').removeAttr('src')
jQuery('#image').show();



reader.onload = function (e) {
$('#image').attr('src', e.target.result);
$('#image').attr('style', "height:200px !important;width:200px !important;");

}

reader.readAsDataURL(input.files[0]);
}
}

function remove() {
jQuery('#image').removeAttr('src'); 
document.getElementById("iconname").value = "";

}

</script>


<script type="text/javascript">
	/* Add data */ /*Form Submit*/

	$(document).ready(function(){
	 

	/* Add data */ /*Form Submit*/
	$("#xin-form").submit(function(e){
		var fd = new FormData(this);
		var obj = $(this), action = obj.attr('name');
		fd.append("is_ajax", 1);
	 
		fd.append("form", action);
		e.preventDefault();
		$('.save').prop('disabled', true);
		
		$.ajax({
			url: e.target.action,
			type: "POST",
			data:  fd,
			contentType: false,
			cache: false,
			processData:false,
			success: function(JSON)
			{
				if (JSON.error != '') {
				toastr.error(JSON.error);
				$('.save').prop('disabled', false);
				} else {
				toastr.success(JSON.result);
				$('.save').prop('disabled', false);
		 	window.location.href="<?php echo base_url();?>industry/products";
				}
			},
			error: function() 
			{
				toastr.error(JSON.error);
			 
				$('.save').prop('disabled', false);
			} 	        
	   });
	});

	});
 
</script>
 