<style type="text/css">	
.navigation .menu .menu-icon {
    
    top: 15px !important ;
    left: 15px !important ;
    width: 25px !important ;
    font-size: 12px !important ;
    
}

.navigation .menu>li>a {
     
    padding: 14px 30px 14px 50px !important ;
   
}


.navigation .menu>li.active>a {
    background: #1c1d8a !important;
     color: 	white !important	;

}
 



.navigation  li .active a {
      
    background-color: #3889eb !important;
    border-color: #ffff !important;
    color: 	white !important	;
   
}


.main-content {
padding-top: 70px !important ;
}


</style>

<div class="main-menu">
<header class="header">
<!-- <img src="assets/images/logo.png"> -->
<button type="button" class="button-close fa fa-times js__menu_close"></button>
</header>
<!-- /.header -->
<div class="content">

<div class="navigation">
<ul class="menu js__accordion">
<li class="logo_sec text-center">
 <img src="<?php echo base_url() ?>assets/images/logo.png" alt="" class="ico-img">
</li>
<li id="home">
<a class="waves-effect" href="<?php echo base_url() ?>industry/dashboard"><img class="menu-icon " src="<?php echo base_url()?>assets/images/sideheader_icons/dashboard.png">
<span> <?php echo $this->Admin_model->translate("Dashboard") ?>  </span></a></li>

 


<li id="2"><a class="waves-effect parent-item" href="<?php echo base_url()?>industry/categories"><img class="menu-icon " src="<?php echo base_url()?>assets/images/sideheader_icons/roles.png"><span> <?php echo $this->Admin_model->translate("Categories") ?> </span> </a>

</li>
 
<li id="3"><a class="waves-effect parent-item" href="<?php echo base_url()?>industry/colors"><img class="menu-icon " src="<?php echo base_url()?>assets/images/sideheader_icons/roles.png"><span> <?php echo $this->Admin_model->translate("Colors") ?> </span> </a>

</li>
<li id="4"><a class="waves-effect parent-item" href="<?php echo base_url()?>industry/sizes"><img class="menu-icon " src="<?php echo base_url()?>assets/images/sideheader_icons/roles.png"><span> <?php echo $this->Admin_model->translate("Sizes") ?> </span> </a>

</li>


<li id="5">
<a class="waves-effect" href="<?php echo base_url() ?>industry/products"><img class="menu-icon " src="<?php echo base_url()?>assets/images/sideheader_icons/users.png">
<span> <?php echo $this->Admin_model->translate("Products") ?> </span></a></li>
 
 <li id="7">
<a class="waves-effect" href="<?php echo base_url() ?>industry/inventory"><img class="menu-icon " src="<?php echo base_url()?>assets/images/sideheader_icons/password.png">
<span> <?php echo $this->Admin_model->translate("Inventory") ?>  </span></a></li> 

<li id="8">
<a class="waves-effect" href="<?php echo base_url() ?>industry/orders"><img class="menu-icon " src="<?php echo base_url()?>assets/images/sideheader_icons/password.png">
<span> <?php echo $this->Admin_model->translate("Orders") ?>  </span></a></li> 


<li id="9">
<a class="waves-effect" href="<?php echo base_url() ?>industry/reports"><img class="menu-icon " src="<?php echo base_url()?>assets/images/sideheader_icons/password.png">
<span> <?php echo $this->Admin_model->translate("Reports") ?>  </span></a></li> 

<!--  
 
 <li id="12"><a class="waves-effect parent-item js__control" href="#"><img class="menu-icon " src="<?php echo base_url()?>assets/images/sideheader_icons/settings.png"><span><?php echo $this->Admin_model->translate("Settings") ?></span><span class="menu-arrow fa fa-angle-down"></span></a>

<ul class="sub-menu js__content" id="s3">
 <li   id="s3_1"><a href="<?php echo base_url()?>industry/contact"><?php echo $this->Admin_model->translate("Contact") ?></a></li>
 <li   id="s3_2" ><a href="<?php echo base_url()?>industry/listfaq"><?php echo $this->Admin_model->translate("FAQ") ?> </a></li>
  <li   id="s3_3"><a href="<?php echo base_url()?>industry/editmessage"><?php echo $this->Admin_model->translate("Send Notifications") ?></a></li>
</ul>

</li> -->
<!-- 
 <li id="13">
<a class="waves-effect" href="<?php echo base_url() ?>industry/translation"><img class="menu-icon " src="<?php echo base_url()?>assets/images/sideheader_icons/dashboard.png">
<span> <?php echo $this->Admin_model->translate("Translation") ?>   </span></a></li> -->

<li >
<a class="waves-effect" href="<?php echo base_url() ?>industry/logout"><img class="menu-icon " src="<?php echo base_url()?>assets/images/sideheader_icons/logout.png">
<span> <?php echo $this->Admin_model->translate("Logout") ?>   </span></a></li>
</ul>
 
</div>

</div>
<!-- /.content -->
</div>
<!-- /.main-menu -->
