<h5><u>Selected Course Details</u> </h5><br>
<?php 
$courses =  $this->cart->contents()  ;


if( !empty($courses)){
    foreach($courses as $value){ ?>
     
   
<b>Course name : <?php echo $value['name'] ?></b> <br> 
 Admin Name : <?php echo $value['admin'] ?><br>
 Phone No. : <?php echo $value['phone'] ?><br>
 Slot : <?php echo $value['slot'] ?><br>
 Date : <?php echo $value['tdate'] ?><br>
 No. of Candidates : <?php echo $value['qty'] ?><br>
 Price : <?php echo $value['total'] ?><br> <a href="javascript:void(0)" data-id="<?php echo $value['rowid'] ?>"  class="remove_course   float-right "><i class="fa fa-trash btn btn-danger"></i></a><br>
   
 <br><br>
 <?php    }?>
 <button class="btn btn-success registration" >Register</button>

 <?php }
?>

 


<script type="text/javascript">
  /* Add data */ /*Form Submit*/

jQuery(document).ready(function(){
        
$.ajax({ 
type: "POST",
url: "<?php echo base_url(); ?>"+'admin/multiselect_allowed',

success: function(data) {
 
var span = document.createElement("span");
span.innerHTML = data;


  if(data == 0 ){
   
 
  } else{
    swal({
        title: "Multiple Course Selection",
            content:span,
            icon: "warning",
            button: "Ok",
            
            
  })
  }
             
 },

});

  });
  </script>
 