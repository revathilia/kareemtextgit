 
 
<?php 
$courses =  $this->cart->contents()  ;

 ?>



 
<form action="<?php echo base_url()?>user/register_students" id="trainingform" method="post">

<input type="hidden" id="multiselect_pending" value="">

 
<?php 
$courses =  $this->cart->contents()  ;


if( !empty($courses)){
    foreach($courses as $value){  

      $this->db->where('id',$value['id']);
      $training =  $this->db->get('training_courses')->row() ;
  
      if($training->multiselect == 1){ ?>
    
        <input type="hidden" class="form-control multiselect" required  id = "multiselect_<?php echo $value['id'] ; ?>" name="multiselect_<?php echo $value['id'] ; ?>" value="<?php echo $value['id'] ; ?>" >

     <?php }



    $direct = '' ;
    $companyid = $this->Admin_model->get_type_name_by_id('training_courses','id',$value['id'],'company_id') ; 
    $direct =  $this->Admin_model->get_type_name_by_id('companies','id',$companyid,'direct') ; 
 
    ?>
  


 

<table><tr><th>Training name</th>
<th>Date</th>
<th>Slot</th>
<th>No. of trainees</th>
<th>Total Price</th></tr>
     
   <tr>
       <td><?php echo $value['name'] ?></td>
       <td><?php echo $value['tdate'] ?></td>
       <td><?php echo $value['slot'] ?></td>
       <td><?php echo $value['qty'] ?></td>  
       <td><?php echo $value['total'] ?></td>  
    </tr> 

    </table>

    <table><tr><th>Admin name</th>
<th>Admin Phone No.</th>
</tr>
     
   <tr>
       <td><?php echo $value['admin'] ?></td>
       <td><?php echo $value['phone'] ?></td>
      
    </tr> 

    </table>


  
    <table>
     <tr>
         <th>No.</th>
         <th> Name</th>
         <th> Email</th>
          <th>Business Unit</th>
           <th>Department</th>
         <th>National ID / iqama Number</th>
         <?php if($direct == 'N'){ ?>
         <th>Contractor Name</th>
         <?php  } ?>
         <th>Nationality</th>
     </tr>



        
<?php for ($i = 1; $i <= $value['qty']; $i++) { ?>

<tr> <td><?php echo $i ?></td>
       <td><input type="text" placeholder=" Name" class="form-control" required name="student_name[]"></td>
       <td><input type="email" placeholder=" Email" class="form-control" required name="student_email[]"></td>
       <td>
<select class="businessunit"  data-id="<?php echo $i.$value['rowid'] ?>" id="business_<?php echo $i.$value['rowid'] ?>" required name="business_unit[]"><option value="">--Select--</option>
<option value="MAC">MAC</option>
<option value="MBAC">MBAC</option>
<option value="MRC">MRC</option>
<option value="AlBaitha">AlBaitha</option>
</select>
        

      </td>
       <td>
<select class="department" id="department_<?php echo $i.$value['rowid'] ?>" required name="department[]"><option value="">--Select--</option>
 
</select>


        </td>
       <td><input type="text" placeholder="National ID / iqama Number" class="form-control nationalId" data-id="<?php echo $i.$value['rowid'] ?>" data-rowid="<?php echo $value['rowid'] ?>" id="nId_<?php echo $i.$value['rowid'] ?>" required  pattern="[0-9]+" title="add numeric values only"  name="iquama_number[]"></td>
       <?php if($direct != 'Y'){ ?>
          <td><input type="text" placeholder="Contactor Name" required class="form-control" name="contractor_name[]"></td> 
        <?php  } ?>
       <td>
        
         
         
       
    <select class="form-control" name="nationality[]">
    <?php  foreach($countries as $values){ ?>
<option value="<?php echo $values['country'] ; ?>"> <?php  echo $values['country'] ; ?> </option>
      <?php  } ?>
</select>
       
      
      </td> 
        <input type="hidden" name="rowid[]" value="<?php echo $value['rowid'] ?>">  
    </tr> 
   
   <?php  } 
         ?>
     
   
  
 <?php    }?>

 </table>


  
 <?php } ?>
 
 <a href="javascript:void(0)" class="btn btn-success btn-block add_payment" >Add Payment Details</a>

 <div id="secondpart">
   <h4>Payment Mode</h4>
   <br>

   <div class="row">
   <div class="col-4 col-md-4">
<div class="col-2 col-md-2">
<input class="checkcategory"
type="radio"
id="pay_inclass"
name="payment_mode"
value="pay_inclass"   >
</div>
<div class="col-10 col-md-9">

<label for="cat-in-house-training">  
<span class="filter-checkbox"></span>
Payment in Class                                                                               </label>

</div>
</div>
<div class="col-3 col-md-3">
<div class="col-2 col-md-2">
<input class="checkcategory"
type="radio"
id="attach_po"
name="payment_mode"
value="attach_po"   >
</div>
<div class="col-10 col-md-9">

<label for="cat-in-house-training">  
<span class="filter-checkbox"></span>
Attach PO                                                                              </label>

</div>
</div>

<div class="col-5 col-md-5">
 
<input class="form-control"
type="file"
id="attach_file"
name="attach_po"
value=""   >
</div>
 

</div>


 

 

   <button class="btn btn-success btn-block save" type="submit">Save details</button>
 </div>

</form>


  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

 <script type="text/javascript">
  /* Add data */ /*Form Submit*/

  jQuery(document).ready(function(){

   

    $('#secondpart').hide();
    $('#attach_file').hide();

   


  /* Add data */ /*Form Submit*/
  jQuery("#trainingform").submit(function(e){
    if($('#multiselect_pending').val() ==''){
      e.preventDefault();
    var fd = new FormData(this);
    var obj = jQuery(this), action = obj.attr('name');
    fd.append("is_ajax", 1);
   
    fd.append("form", action);
    
    jQuery('.save').prop('disabled', true);
    
    
    jQuery.ajax({
      url: e.target.action,
      type: "POST",
      data:  fd,
      contentType: false,
      cache: false,
      processData:false,
      success: function(JSON)
      {

         swal({
            title: "Registered Successfully",
            text: 'Registration Completed successfully. You will receive a confirmation Email soon.',
            icon: "success",
            button: "Ok",
            
  })
setTimeout(function() {
     window.location.href="<?php echo base_url();?>user";
}, 5000);


 

      
       },
      error: function() 
      {
           swal({
            title: "Registration Failed",
            text: 'Try again',
            icon: "error",
            button: "Ok",
            
  });
       
        jQuery('.save').prop('disabled', false);
      }           
     });
    }else{
      swal({
            title: "Form submission Failed",
            text: 'Check course selection',
            icon: "error",
            button: "Ok",
            
  });
       
        jQuery('.save').prop('disabled', false);
    }
    
  });

  });

  $(document).on( "click", ".add_payment", function(e) {

    if($('#multiselect_pending').val() =='pending'){

      swal({
            title: "Warning",
            text: 'Check course selection',
            icon: "error",
            button: "Ok",
            
  });

    }else{
      $('#secondpart').show();
$('.add_payment').hide();
    }
 


  });

  $('.checkcategory').click(function() {
   if($('#attach_po').is(':checked')) { 
      
$('#attach_file').show();

$("#attach_file").prop('required',true);
    }else{
      $('#attach_file').hide();

$("#attach_file").prop('required',false);
    }
});


$(document).ready(function() {
$('.businessunit').on('change', function() {
var business =  $(this).data('id');
var business_unit = $('#business_'+business).val();

$.ajax({ 
type: "POST",
url: "<?php echo base_url(); ?>"+'user/get_departments/',
data: {unit:business_unit},
success: function(data) {

   
   if(data && data !=""){
    $('#department_'+business).html(data);

   }else{
     
     $('#department_'+business).removeAttr('required');
     $('#department_'+business).html('<option>NA</option>');
   } 


         
},

});
}); 

  $('.nationalId').on('keyup', function() {

 
  var national =  $(this).data('id');
  var nationalId = $('#nId_'+national).val();
  var rowid =  $(this).data('rowid');
  $('#multiselect_pending').val('');
  $('.add_payment').show();

  //if ($(".multiselect")[0]){
      // Do something if class exists

    var myArray = []; // Creating a new array object
    // get all input elements
    var $elems = $('.nationalId');

    // we store the inputs value inside this array
    var values = [];
    // return this
    var isDuplicated = false;
    // loop through elements
    $elems.each(function () {
      //If value is empty then move to the next iteration.
      if(!this.value) return true;
      //If the stored array has this value, break from the each method
      if(values.indexOf(this.value) !== -1) {
        isDuplicated = true;
        return false;
      }
      // store the value
      values.push(this.value);
 
    });   
   //if( isDuplicated == true) {


    var rowid = []; // Creating a new array object
    var nId = []; // Creating a new array object
    // get all input elements
    var $elems = $('.nationalId');
   
    // loop through elements
    $elems.each(function () {
   
  // myArray['rowid'][] = $(this).data('rowid'); // Setting the attribute a to 200
  // myArray['nId'][] = this.value; // Setting the attribute b to 300

  // var obj = {'rowid' : $(this).data('rowid'), 'nId' : this.value } ;

  rowid.push($(this).data('rowid'));
  nId.push( this.value );

    });  


   
  $.ajax({ 
  type: "POST",
  url: "<?php echo base_url(); ?>"+'admin/check_multiselection',
  data: {nId:nId,rowid:rowid},

  success: function(data) {
  
  var span = document.createElement("span");
  span.innerHTML = data;

 
    if(data == 0 ){

     $('.add_payment').show();
   
    
     

//  setTimeout(function() {
//   $('#myModal').modal('hide');
// }, 5000);


  
    } else{

     var msg = data.split('____') ;


if(msg[0]== 'blocked'){
  var title = "Trainee Blocked" ;
  var span = document.createElement("span");
  span.innerHTML = msg[1] ;
}else{

   var title = "Multiple Course Selection" ;
  var span = document.createElement("span");
  span.innerHTML = msg ;
}

 


    $('#multiselect_pending').val('pending');
    $('.add_payment').hide();


      swal({
          title: title,
              content:span,
              icon: "warning",
              button: "Ok",
              
              
    });

    
    
              
  }

  }


    //alert($(this).data('rowid'));
  //} 
 // } 

  // $.ajax({ 
  // type: "POST",
  // url: "<?php echo base_url(); ?>"+'user/get_status',
  // data: {rowid:rowid,nationalId:nationalId},
  // success: function(data) {

    
  });

          
 
  });
});
 
 
  
</script>