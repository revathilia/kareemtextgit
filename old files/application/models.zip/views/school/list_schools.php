 <?php $this->load->view('school/header');?>
<body>
<?php $this->load->view('school/top_header');?>
<?php $this->load->view('school/side_header');?>


<div id="wrapper">
<div class="main-content">
<div class="row small-spacing">
<div class="col-xs-12">
     <div class="box-content card white">
<div class="box-title row">
    <div class='col-md-4'><h4><?php echo $this->Admin_model->translate("School List") ?></h4></div>
    <div class='col-md-4'></div>
    <div class='col-md-2'> 
         <a href="<?php echo base_url(); ?>school/newschool"><button class="btn btn-warning btn-block"> <?php echo $this->Admin_model->translate("Add New") ?></button></a> 
 
    </div>
  <!--   <div class="col-md-2 ">
      <button type="button" class="btn btn-primary btn-sm btn-block changesort" data-toggle="modal"  data-target="#boostrapModal-1"   ><?php echo $this->Admin_model->translate("Change Service Order")?></button>
    </div> -->

</div>

 
<div class="box-content">
 <div class="table-responsive">
  <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
      <tr>
<th><?php echo $this->Admin_model->translate("No") ?></th>
<!-- <th>User Id</th> -->
<th><?php echo $this->Admin_model->translate("School Name") ?></th>
 <th><?php echo $this->Admin_model->translate("Type") ?></th>
<th><?php echo $this->Admin_model->translate("Logo") ?></th>

 <th><?php echo $this->Admin_model->translate("status") ?></th>
 

<th><?php echo $this->Admin_model->translate("Action") ?></th>
</tr>
      
</thead>
<tbody>
<?php foreach ($schooldet as $value) {
  ?>
 <tr>
<td><?php echo $value['id'] ?></td>
<!-- <th>User Id</th> -->
<td><?php echo  $value['school_name']  ?></td>
<td><?php echo ucfirst($value['school_type']) ?></td>
<td>

    <?php if(!empty($value['school_logo'])){ ?>
<img   class="img-thumb" src="<?php echo base_url().'uploads/images/school/'. $value['school_logo']  ; ?>"  >

  <?php } ?>

</td> 

 <td>
  <?php if($value['status']=='Y'){ ?>

    <a onclick="statusupdate(<?php echo $value['id'] ?>,'D');  return false ;" href="javascript:void(0)"  class="btn btn-success btn-xs"><?php echo $this->Admin_model->translate('Enabled') ?> </a>

    

  <?php } else if($value['status']=='D'){ ?>
     
    <a onclick="statusupdate(<?php echo $value['id'] ?>,'Y');  return false ;" href="javascript:void(0)"  class="btn btn-danger btn-xs"><?php echo $this->Admin_model->translate('Disabled') ?> </a>

   
    
  <?php } ?>
   
 

     </td> 
   
<td>
 
<a href="<?php echo base_url()?>school/editschool/<?php echo $value['id']?>">&nbsp;&nbsp;<button type="button" class="btn btn-info   btn-xs waves-effect waves-light"><i class="ico fa fa-pencil"></i></button></a><br/>


 <a onclick="statusupdate(<?php echo $value['id'] ?>,'delete');  return false ;" href="javascript:void(0)"  class="btn btn-danger    btn-xs waves-effect waves-light"> <i class="ico fa fa-trash"></i> </a>


    </td>

</tr>

  <?php
} ?>
  

</tbody>
    
    </table>
</div>


<!-- /.box-content -->
</div>
<!-- /.col-lg-6 col-xs-12 -->
</div>
</div>

</div>
</div>
</div>
</body>

<div class="modal fade" id="boostrapModal-1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content" id="serviceid">
      
    </div>
  </div>
</div>


 <?php $this->load->view('school/footer');?>

 <script>
    function statusupdate($id,$status){

 
$.ajax({ 
type: "POST",
url: "<?php echo base_url(); ?>"+'school/school_status/',
data: {id:$id,status:$status},
}).done(function(response){

 if(response=='false'){
   toastr.error("Access denied");
 }

location.reload();

});

}

  function loginupdate($id,$status){

 
$.ajax({ 
type: "POST",
url: "<?php echo base_url(); ?>"+'school/login_status_service/',
data: {id:$id,status:$status},
}).done(function(response){

 if(response=='false'){
   toastr.error("Access denied");
 }

location.reload();

});

}


$(document).on('click', '.changesort', function(){  


// var serviceid = document.getElementById("service").value  ;
 
// var serviceid = $(this).data('serviceid') ;

 
$.ajax({  
url:"<?php echo base_url() ?>admin/changeservicessort",  
method:"POST",  
//data:{serviceid:serviceid,qid:questionid },
success:function(data){ 

$('#serviceid').html(data);  
$('#boostrapModal-1').modal('show');
    

}  
});  


});


</script>