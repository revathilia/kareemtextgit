 <?php $this->load->view('school/header');?>
<body>
<?php $this->load->view('school/top_header');?>
<?php $this->load->view('school/side_header');?>


<div id="wrapper">
<div class="main-content">
<div class="row small-spacing">
<div class="col-xs-12">
     <div class="box-content card white">
<div class="box-title row">
    <div class='col-md-10'><h4><?php echo $this->Admin_model->translate("Access Denied") ?></h4></div>
     
</div>

 
 
<!-- /.col-lg-6 col-xs-12 -->
</div>
</div>

</div>
</div>
</div>
 


</body>
 <?php $this->load->view('school/footer');?>

 