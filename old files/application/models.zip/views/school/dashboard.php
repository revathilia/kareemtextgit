<?php $this->load->view('school/header');?>
 <meta name="viewport" content="width=device-width, initial-scale=1">
<body>
<?php $this->load->view('school/top_header');?>
<?php $this->load->view('school/side_header');?>
  
 
<div id="wrapper">
<div class="main-content">
 
</div>
</div>
<!-- ================================================== -->
 <?php $this->load->view('school/footer');?>

