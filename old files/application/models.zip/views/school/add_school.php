<?php $this->load->view('school/header');?>
<body>
<?php $this->load->view('school/top_header');?>
<?php $this->load->view('school/side_header');?>

<?php $session = $this->session->userdata('schooladmindet');?>

<!--  TinyMCE   -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugin/tinymce/skins/lightgray/skin.min.css">
<!--    Must include this script FIRST  -->
  <script src="<?php echo base_url(); ?>assets/plugin/tinymce/tinymce.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Poppins" />



<div id="wrapper">
<div class="main-content">
<div class="row small-spacing">

<div class="box-content card white">
<div class="box-title row">
<div class='col-md-4'><h4><?php echo $this->Admin_model->translate("Add School") ?></h4></div>
<div class='col-md-6'></div>
<div class='col-md-2'> 
<a href="<?php echo base_url(); ?>school/schools"><button class="btn btn-warning"><?php echo $this->Admin_model->translate("School List") ?></button></a>
</div>
</div>




<div class="card-content">



<?php $attributes = array('name' => 'edit_driver', 'id' => 'xin-form', 'autocomplete' => 'off');?>
<?php $hidden = array('_user' => $session['s_user_id']);?>
<?php echo form_open('school/addschool', $attributes, $hidden);?>
<div class="form-body">
<div class="row"> 
<div class="col-md-12">
<div class="form-group">
<label for="first_name"><?php echo $this->Admin_model->translate("School Name") ?></label>
<input class="form-control" placeholder="<?php echo $this->Admin_model->translate("school name") ?>" name="school_name" type="text" value="">
</div>
</div>
</div>

 <div class="row"> 
                <div class="col-md-12">
                  <div class="form-group">

                             <label for="xin_employee_password"><?php echo $this->Admin_model->translate("Select Class levels") ?> </label>

                    <select class="select2_2 form-control inputfield" multiple="" name="class_levels[]">
                    <option value="">  --Select--</option>

                    <?php 

                    foreach ($levels as  $level) { ?>
                     <option value="<?php echo $level['id'] ?>"><?php echo $level['class_type'] ?></option>
                   <?php   } ?>
                   
                    
                     </select>
                    
                  </div>
                </div>
                      
            </div>


<div class="row"> 
<div class="col-md-6">
<div class="form-group">
<label for="first_name"><?php echo $this->Admin_model->translate("School Logo") ?></label>
     <input type="file" id="imgInp" name="school_logo" onchange="readURL(this);" class="form-control " >
                      <small>Upload files only: gif,png,jpg,jpeg</small>

</div>
</div>

 
<div class="col-md-6">
        <div class='form-group'>
          
          <img   class="img-thumb" src="" style="height:100px !important;width:100px !important; " id="image">  
          
        </div>
      </div>


</div>
 <div class="row"> 
                <div class="col-md-12">
                  <div class="form-group">

                             <label for="xin_employee_password"><?php echo $this->Admin_model->translate("School Type") ?> </label>

                    <select class="form-control" name="school_type">
                    
                    <option value="girls">Girls </option>              
                     <option value="boys">Boys </option>
                        <option value="mixed" selected >Mixed </option>
                  
                   
                    
                     </select>
                    
                  </div>
                </div>
                      
            </div>



</div>
<div class="form-actions"> <?php echo form_button(array('name' => 'hrsale_form', 'type' => 'submit', 'class' => 'btn btn-primary btn-block', 'content' => '<i class="fa fa fa-check-square-o"></i>&nbsp;&nbsp;'.$this->Admin_model->translate("Save"))); ?> </div>
<?php echo form_close(); ?> </div>

</div>
</div>
</div>
</div>
</body>


<!-- ================================================== -->
<?php $this->load->view('school/footer');?>
 


 <script type="text/javascript">
/* Add data */ /*Form Submit*/

$(document).ready(function(){
  // content1.triggerSave();
  //   content2.triggerSave();

 // 

/* Add data */ /*Form Submit*/
$("#xin-form").submit(function(e){
  tinyMCE.triggerSave();
var fd = new FormData(this);
var obj = $(this), action = obj.attr('name');
fd.append("is_ajax", 1);

fd.append("form", action);
e.preventDefault();
$('.save').prop('disabled', true);
 
$.ajax({
url: e.target.action,
type: "POST",
data:  fd,
contentType: false,
cache: false,
processData:false,
success: function(JSON)
{
if (JSON.error != '') {
toastr.error(JSON.error);
$('.save').prop('disabled', false);
} else {
toastr.success(JSON.result);
$('.save').prop('disabled', false);
window.location.href="<?php echo base_url();?>school/schools";
}
},
error: function() 
{
toastr.error(JSON.error);

$('.save').prop('disabled', false);
}           
});
});

});

</script>


 <script type="text/javascript">


imgInp.onchange = evt => {
  const [file] = imgInp.files
  if (file) {
    image.src = URL.createObjectURL(file)
  }
}
</script>
