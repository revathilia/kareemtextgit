 
<u>  <h3 class="modal-title text-center " id="myModalLabel">Status Update</h3></u>
<br/>
 
<form class="order_form" id="status_form" method="POST" action="<?php echo base_url();?>admin/request_status_update">

  <input type="hidden" name="requestid" id="service" value="<?php echo $requestid ?>">


 

<div class="form-group">
<label class="control-label mb-10 text-left"><?php echo $this->Admin_model->translate("Remarks") ?> </label>
 
<textarea placeholder="Add remarks here...." name="remarks" class="form-control" > </textarea>
</div>

 

<div class="row">

<div class="col-md-12">
<div class="form-group">
<label class="control-label mb-10 text-left"><?php echo $this->Admin_model->translate("Status") ?> </label>
<select class="form-control" id="field_type" name="status"><option value="">--Select--</option>
  <option value="new" <?php if($reqstatus->status == 'new'){ echo 'selected' ; } ?>>New</option>
<option value="pending" <?php if($reqstatus->status == 'pending'){ echo 'selected' ; } ?>>Pending</option>
<option value="contacted" <?php if($reqstatus->status == 'contacted'){ echo 'selected' ; } ?>>Contacted</option>
<option value="closed" <?php if($reqstatus->status == 'closed'){ echo 'selected' ; } ?>>Closed</option>

</select>
</div>
</div>
 
</div>
 
<p class="text-center"><button type="submit" class="btn btn-block save"><?php echo $this->Admin_model->translate("Save") ?></button></p>

</form>
       

 

 <script type="text/javascript">
/* Add data */ /*Form Submit*/
 


$(document).ready(function(){


/* Add data */ /*Form Submit*/
$("#status_form").submit(function(e){
var fd = new FormData(this);
var obj = $(this), action = obj.attr('name');
fd.append("is_ajax", 1);

fd.append("form", action);
e.preventDefault();
$('.save').prop('disabled', true);

$.ajax({
url: e.target.action,
type: "POST",
data:  fd,
contentType: false,
cache: false,
processData:false,
success: function(JSON)
{
if (JSON.error != '') {
toastr.error(JSON.error);
$('.save').prop('disabled', false);
} else{

//$('#boostrapModal-1').remove();
toastr.success(JSON.result);
$('.save').prop('disabled', false);
 
//$('#modal-container').remove();
   $('#boostrapModal-1').modal('toggle');
    location.reload();
} 
}           
});
});

});
      </script>