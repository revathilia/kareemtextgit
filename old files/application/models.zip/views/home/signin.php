<!doctype html>
<html class="no-js" lang="zxx">


<!-- Mirrored from tunatheme.com/tf/html/vicodin-preview/vicodin/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 07 Mar 2023 08:39:14 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Kareemtex</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Place favicon.png in the root directory -->
    <link rel="shortcut icon"href="<?php echo base_url()?>assets/home_assets/img/favicon.png" type="image/x-icon" />
    <!-- Font Icons css -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/home_assets/css/font-icons.css">
    <!-- plugins css -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/home_assets/css/plugins.css">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/home_assets/css/style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/home_assets/css/responsive.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/toastr/toastr.min.css">

</head>

<body>

<!-- HEADER AREA START (header-5) -->
<?php include 'header.php'?>
    <!-- HEADER AREA END -->
<br><br><br><br><br><br>
<section class="log">
    <div class="container">
        <div class="row ">
        
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="log2">
                <br>
            <h6 class="text-center">Sign-Up</h6>
            <hr class="li-orangees">
            <br>
            <form id="signin-form" action="<?php echo base_url() ?>home/submitsignup" method="post" class="signin">
                            <div class="row">
                                <div class="col-md-10">
                                    <div class="input-item input-item-name ">
                                        <label>Name</label>
                                        <input type="text" name="name" class="form-control"  >
                                    </div>
                                </div>
                                                               <div class="col-md-10">
                                    <div class="input-item input-item-email ">
                                    <label>Email</label>
                                        <input type="email" name="email" class="form-control"  >
                                    </div>
                                </div>
                                
                                <div class="col-md-10">
                                    <div class="input-item input-item-phone ">
                                    <label>Phone Number</label>
                                        <input type="text" name="phone" class="form-control" >
                                    </div>
                                </div>
                            </div>
                           
                            
                            <div class="btn-wrapper mt-0">
                             <p class="text-center">   <button class="btn btn-orange" type="submit">Submit</button></p>
                            </div>
                            <p class="form-messege mb-0 mt-20"></p>
                        </form>

</div>
</div>
</div>
</div>
</section>


 <!-- preloader area start -->
 <div class="preloader d-none" id="preloader">
        <div class="preloader-inner">
            <div class="spinner">
                <div class="dot1"></div>
                <div class="dot2"></div>
            </div>
        </div>
    </div>
    <!-- preloader area end -->

    <!-- All JS Plugins -->
    <script src="<?php echo base_url()?>assets/home_assets/js/plugins.js"></script>
    <!-- Main JS -->
    <script src="<?php echo base_url()?>assets/home_assets/js/main.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/toastr/toastr.min.js"></script> 
    <script type="text/javascript">
    $(document).ready(function(){
        toastr.options.closeButton = true;
        toastr.options.progressBar = true;
        toastr.options.timeOut = 3000;
        toastr.options.preventDuplicates = true;
        toastr.options.positionClass = "toast-top-center";
        var site_url = '<?php echo site_url(); ?>';
    });
    </script>

    <script type="text/javascript">

	$(document).ready(function () {
		$("#signin-form").submit(function (e) {
			var fd = new FormData(this);
			var obj = $(this),
				action = obj.attr('name');
			fd.append("is_ajax", 1);

			fd.append("form", action);
			e.preventDefault();
			$('.save').prop('disabled', true);

			$.ajax({
				url: e.target.action,
				type: "POST",
				data: fd,
				contentType: false,
				cache: false,
				processData: false,
				success: function (JSON) {
					if (JSON.error != '') {
						toastr.error(JSON.error);
						$('.save').prop('disabled', false);
					} else {
						toastr.success(JSON.result);
						$('.save').prop('disabled', false);
						window.location.href = "<?php echo base_url();?>home/login";
					}
				},
				error: function () {
					toastr.error(JSON.error);

					$('.save').prop('disabled', false);
				}
			});
		});

	});
</script>