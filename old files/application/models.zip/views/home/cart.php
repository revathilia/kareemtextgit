<!doctype html>
<html class="no-js" lang="zxx">



<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Kareemtex</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Place favicon.png in the root directory -->
    <link rel="shortcut icon"href="<?php echo base_url()?>assets/home_assets/img/favicon.png" type="image/x-icon" />
    <!-- Font Icons css -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/home_assets/css/font-icons.css">
    <!-- plugins css -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/home_assets/css/plugins.css">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/home_assets/css/style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/home_assets/css/responsive.css">
</head>

<body>

<div class="body-wrapper">

 
 <?php $this->load->view('home/header'); ?> 
<br><br><br><br>
    <!-- SHOPING CART AREA START -->
    <div class="liton__shoping-cart-area mb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
<div id="cart">

 <?php $this->load->view('home/loadcart'); ?> 

</div>


                    
                </div>
            </div>
        </div>
    </div>
    <!-- SHOPING CART AREA END -->

    <!-- FOOTER AREA START -->
     <?php $this->load->view('home/footer'); ?> 
    <!-- FOOTER AREA END -->

</div>
<!-- Body main wrapper end -->

    <!-- All JS Plugins -->
    <script src="<?php echo base_url()?>assets/home_assets/js/plugins.js"></script>
    <!-- Main JS -->
    <script src="<?php echo base_url()?>assets/home_assets/js/main.js"></script>

       <script type="text/javascript">
                        
        
// $(document).on('input propertychange paste', '.loadqty', function(){
     
 $(document).ready(function(){

     $('.loadqty .qtybutton').click(function(e) {  

        
  
  var id=$(this).closest('.loadqty').attr('data-id');;
  var res = id.split("_")[1];
    
//var res = $id ;
$quantity = $('#qty_'+res).val() ;
$rowid = $('#qty_'+res).data('rowid');
$price = $('#qty_'+res).data('price');

 
 $.ajax({ 
type: "POST",
url: "<?php echo base_url(); ?>"+'home/update_cart',
data: {qty:$quantity,rowid:$rowid,price:$price,viewname:'viewcart'},
}).done(function(response){
 
 $("#cart").html(response); 
 cartupdate();
});     

});
     });
    </script>
  
</body>


</html>

