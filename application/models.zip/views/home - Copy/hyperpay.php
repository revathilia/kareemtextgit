<form action="<?php echo base_url()?>home/paymentstatus/" class="paymentWidgets" data-brands="VISA MASTER AMEX"></form>
<script src="https://test.oppwa.com/v1/paymentWidgets.js?checkoutId=<?php echo $checkoutId ?>"></script>
