<?php $this->load->view('admin/header');?>
 <meta name="viewport" content="width=device-width, initial-scale=1">
<body>
<?php $this->load->view('admin/top_header');?>
<?php $this->load->view('admin/side_header');?>
 
 
 
 
<div id="wrapper">
<div class="main-content">

 
 
</div>
</div>

<!-- ================================================== -->
 <?php $this->load->view('admin/footer');?>

