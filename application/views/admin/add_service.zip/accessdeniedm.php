<div class="row ">
<div class="col-xs-12">
     <div class="box-content card white">
<div class="box-title row">
    <div class='col-md-10'><h4><?php echo $this->Admin_model->translate("Access Denied") ?></h4></div>
     
</div>

 
 
<!-- /.col-lg-6 col-xs-12 -->
</div>
</div>

</div>